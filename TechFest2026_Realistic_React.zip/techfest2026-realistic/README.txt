TECHFEST 2026 - REALISTIC REACT VERSION

This is a Vite + React + React Router + Axios project. The interface and all visible copy are in English.

To use it in your existing project:
1. Copy the contents of this folder into your existing techfest2026-react folder, replacing src and index.html and package.json.
2. Open PowerShell in the project root.
3. Run: npm install
4. Run: npm run dev
5. Open http://localhost:5173/

Features:
- Realistic modern event-festival landing page
- English UI
- Responsive design
- Dark/light theme
- Home, Events, Gallery, Contact, Registration, 404
- Event search and category filter
- Registration validation and success state
- Axios announcement loading with fallback content
