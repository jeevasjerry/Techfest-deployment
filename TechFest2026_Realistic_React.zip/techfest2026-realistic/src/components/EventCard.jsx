import { Link } from "react-router-dom";

export default function EventCard({ event }) {
  return (
    <article className={`event-card accent-${event.color}`}>
      <div className="event-top">
        <span className="category">{event.category}</span>
        <span className="price">{event.price}</span>
      </div>
      <div className="event-icon">{event.category === "Robotics" ? "🤖" : event.category === "Workshop" ? "⚡" : event.category === "Cyber Security" ? "🛡️" : event.category === "Design" ? "🎨" : event.category === "Quiz" ? "🧠" : "💻"}</div>
      <h3>{event.title}</h3>
      <p>{event.description}</p>
      <div className="event-meta">
        <span>📅 {event.date}</span>
        <span>📍 {event.venue}</span>
      </div>
      <div className="card-bottom">
        <span>{event.seats} seats available</span>
        <Link to="/register" state={{ event }} className="arrow-link">Register →</Link>
      </div>
    </article>
  );
}
