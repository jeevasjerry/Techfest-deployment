import EventCard from "./EventCard";

export default function EventList({ events }) {
  if (!events.length) return <div className="empty-state">No events match your search.</div>;
  return <div className="event-grid">{events.map(event => <EventCard key={event.id} event={event} />)}</div>;
}
