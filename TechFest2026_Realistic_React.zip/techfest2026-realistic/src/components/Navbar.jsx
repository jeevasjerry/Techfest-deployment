import { NavLink } from "react-router-dom";
import { useTheme } from "../context/ThemeContext";

export default function Navbar() {
  const { dark, toggleTheme } = useTheme();
  const link = ({ isActive }) => isActive ? "nav-link active" : "nav-link";
  return (
    <header className="navbar">
      <div className="container nav-inner">
        <NavLink to="/" className="brand">
          <span className="brand-mark">TF</span>
          <span><b>TechFest</b><small>2026</small></span>
        </NavLink>
        <nav>
          <NavLink to="/" className={link}>Home</NavLink>
          <NavLink to="/events" className={link}>Events</NavLink>
          <NavLink to="/gallery" className={link}>Gallery</NavLink>
          <NavLink to="/contact" className={link}>Contact</NavLink>
          <NavLink to="/register" className="register-nav">Register</NavLink>
          <button className="theme-btn" onClick={toggleTheme} aria-label="Toggle theme">
            {dark ? "☀️" : "🌙"}
          </button>
        </nav>
      </div>
    </header>
  );
}
