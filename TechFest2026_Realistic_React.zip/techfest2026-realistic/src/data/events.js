export const events = [
  {
    id: 1, title: "CodeSprint 2026", category: "Coding",
    date: "March 21, 2026", time: "9:30 AM – 4:30 PM", venue: "Innovation Lab",
    seats: 120, price: "Free", level: "Open to all",
    description: "A fast-paced team coding challenge covering algorithms, web development and real-world problem solving.",
    color: "violet"
  },
  {
    id: 2, title: "AI & GenAI Workshop", category: "Workshop",
    date: "March 21, 2026", time: "11:00 AM – 1:00 PM", venue: "Seminar Hall A",
    seats: 60, price: "₹199", level: "Beginner friendly",
    description: "Build a practical AI workflow and learn how modern generative AI systems are used in products.",
    color: "cyan"
  },
  {
    id: 3, title: "RoboWars Arena", category: "Robotics",
    date: "March 22, 2026", time: "10:00 AM – 3:00 PM", venue: "Main Arena",
    seats: 40, price: "₹299", level: "Intermediate",
    description: "Design, control and battle your custom robot in an arena built for speed, strategy and engineering.",
    color: "orange"
  },
  {
    id: 4, title: "CyberQuest", category: "Cyber Security",
    date: "March 22, 2026", time: "2:00 PM – 6:00 PM", venue: "Cyber Lab",
    seats: 80, price: "₹149", level: "Intermediate",
    description: "A capture-the-flag challenge featuring web security, cryptography, forensics and OSINT puzzles.",
    color: "green"
  },
  {
    id: 5, title: "UI/UX Design Challenge", category: "Design",
    date: "March 23, 2026", time: "10:30 AM – 1:30 PM", venue: "Design Studio",
    seats: 50, price: "Free", level: "Open to all",
    description: "Turn a real product brief into a polished interface and pitch your design to industry judges.",
    color: "pink"
  },
  {
    id: 6, title: "Tech Trivia Night", category: "Quiz",
    date: "March 23, 2026", time: "5:00 PM – 7:00 PM", venue: "Auditorium", 
    seats: 150, price: "Free", level: "Open to all",
    description: "A high-energy quiz covering technology, science, startups, movies and the internet.",
    color: "blue"
  }
];
