import { useMemo, useState } from "react";
import EventList from "../components/EventList";
import { events } from "../data/events";

export default function Events() {
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("All");
  const categories = ["All", ...new Set(events.map(e => e.category))];
  const filtered = useMemo(() => events.filter(e => (category === "All" || e.category === category) && `${e.title} ${e.description}`.toLowerCase().includes(query.toLowerCase())), [query, category]);
  return <section className="page-section"><div className="container">
    <div className="page-header"><span className="eyebrow">THE LINEUP</span><h1>Events built to challenge you.</h1><p>Find your next competition, workshop or experience.</p></div>
    <div className="filters"><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search events..." /> <select value={category} onChange={e=>setCategory(e.target.value)}>{categories.map(c=><option key={c}>{c}</option>)}</select></div>
    <EventList events={filtered}/>
  </div></section>;
}
