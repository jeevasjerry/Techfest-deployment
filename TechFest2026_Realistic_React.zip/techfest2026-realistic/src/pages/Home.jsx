import { useEffect, useState } from "react";
import axios from "axios";
import { Link } from "react-router-dom";
import { events } from "../data/events";

export default function Home() {
  const [announcements, setAnnouncements] = useState([]);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    axios.get("https://jsonplaceholder.typicode.com/posts?_limit=3")
      .then(r => setAnnouncements(r.data.map(x => ({...x, title: x.id === 1 ? "Registrations are now open" : x.id === 2 ? "Early-bird passes end soon" : "Volunteer applications are live"}))))
      .catch(() => setAnnouncements([
        {id:1,title:"Registrations are now open",body:"Reserve your spot for the biggest student technology festival of the year."},
        {id:2,title:"Early-bird passes end soon",body:"Grab your workshop and competition passes before availability runs out."},
        {id:3,title:"Volunteer applications are live",body:"Join the organizing team and help us build an unforgettable TechFest."}
      ]))
      .finally(() => setLoading(false));
  }, []);
  return (
    <>
      <section className="hero">
        <div className="hero-glow glow-one" /><div className="hero-glow glow-two" />
        <div className="container hero-grid">
          <div className="hero-copy">
            <span className="eyebrow">MAR 21–23 • 2026 • TRIVANDRUM</span>
            <h1>Where <span>technology</span> meets imagination.</h1>
            <p>Three days of coding, AI, robotics, cyber security and design — built for students who want to create what comes next.</p>
            <div className="hero-actions">
              <Link to="/events" className="btn primary">Explore events →</Link>
              <Link to="/register" className="btn ghost">Get your pass</Link>
            </div>
            <div className="trust-row"><span>✦ 2,000+ participants</span><span>✦ 30+ events</span><span>✦ 20+ mentors</span></div>
          </div>
          <div className="hero-card">
            <div className="orbit orbit-a" /><div className="orbit orbit-b" />
            <div className="hero-card-inner">
              <span className="live-dot">● LIVE EVENT</span>
              <strong>TECHFEST<br/><em>2026</em></strong>
              <div className="hero-date">21 — 23 MAR</div>
              <div className="hero-location">📍 Trivandrum, Kerala</div>
            </div>
          </div>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <div className="section-heading"><div><span className="eyebrow">WHAT'S HAPPENING</span><h2>Latest announcements</h2></div><Link to="/contact" className="text-link">Stay connected →</Link></div>
          {loading ? <div className="announcement-loading">Loading announcements…</div> :
            <div className="announcement-grid">{announcements.map(a => <div className="announcement" key={a.id}><span className="announcement-num">0{a.id}</span><div><h3>{a.title}</h3><p>{a.body}</p></div></div>)}</div>}
        </div>
      </section>

      <section className="section muted">
        <div className="container">
          <div className="section-heading"><div><span className="eyebrow">DON'T MISS OUT</span><h2>Featured events</h2></div><Link to="/events" className="text-link">View all events →</Link></div>
          <div className="event-grid">{events.slice(0,3).map(e => <div key={e.id}><EventPreview event={e}/></div>)}</div>
        </div>
      </section>
      <section className="cta-section"><div className="container cta"><div><span className="eyebrow">READY TO BUILD?</span><h2>Your next big idea starts here.</h2></div><Link to="/register" className="btn primary">Register now →</Link></div></section>
    </>
  );
}
function EventPreview({event}) {
  return <article className={`event-card accent-${event.color}`}><div className="event-top"><span className="category">{event.category}</span><span className="price">{event.price}</span></div><div className="event-icon">✦</div><h3>{event.title}</h3><p>{event.description}</p><div className="event-meta"><span>📅 {event.date}</span><span>📍 {event.venue}</span></div><div className="card-bottom"><span>{event.seats} seats</span><Link to="/register" state={{event}} className="arrow-link">Join →</Link></div></article>
}
