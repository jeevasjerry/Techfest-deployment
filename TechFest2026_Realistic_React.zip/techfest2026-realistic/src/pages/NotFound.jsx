import { Link } from "react-router-dom";
export default function NotFound(){return <section className="page-section not-found"><div className="container"><span className="big-number">404</span><h1>Page not found.</h1><p>The page you're looking for doesn't exist.</p><Link to="/" className="btn primary">Back to home</Link></div></section>}
