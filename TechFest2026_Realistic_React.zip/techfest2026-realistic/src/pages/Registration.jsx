import { useLocation } from "react-router-dom";
import { useState } from "react";
import { events } from "../data/events";

export default function Registration() {
  const location = useLocation();
  const [selected, setSelected] = useState(location.state?.event?.id || "");
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState("");
  function submit(e) {
    e.preventDefault(); setError("");
    const form = new FormData(e.currentTarget);
    if (!form.get("name") || !form.get("email") || !selected) { setError("Please complete all required fields."); return; }
    setSubmitted(true);
  }
  const event = events.find(e => e.id === Number(selected));
  return <section className="page-section"><div className="container form-layout">
    <div className="form-intro"><span className="eyebrow">SECURE YOUR SPOT</span><h1>Register for TechFest 2026.</h1><p>Choose an event, enter your details and you're ready to go.</p><div className="steps"><span>01 <b>Choose</b></span><span>02 <b>Register</b></span><span>03 <b>Experience</b></span></div></div>
    <div className="form-card">{submitted ? <div className="success"><div className="success-icon">✓</div><h2>You're registered!</h2><p>Thanks for signing up{event ? ` for ${event.title}` : ""}. A confirmation will be sent to your email.</p><button className="btn primary" onClick={()=>setSubmitted(false)}>Register another person</button></div> :
      <form onSubmit={submit}><label>Full name<input name="name" placeholder="Your name" /></label><label>Email address<input name="email" type="email" placeholder="you@example.com" /></label><label>Select event<select value={selected} onChange={e=>setSelected(e.target.value)}><option value="">Choose an event</option>{events.map(e=><option value={e.id} key={e.id}>{e.title} — {e.price}</option>)}</select></label><label>Institution / College<input name="college" placeholder="College or organization" /></label>{error && <div className="form-error">{error}</div>}<button className="btn primary full">Confirm registration →</button></form>}</div>
  </div></section>;
}
